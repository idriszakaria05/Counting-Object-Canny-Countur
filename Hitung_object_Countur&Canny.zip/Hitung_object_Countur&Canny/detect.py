import sys
import cv2
import numpy as np
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QVBoxLayout, QFileDialog, QSlider, QHBoxLayout, QGroupBox, QFormLayout
)
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer, Qt


class WelcomeScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Selamat Datang")
        self.setFixedSize(400, 250)
        self.setStyleSheet("""
            QWidget {
                background-color: #f0f0f5;
                font-family: Arial;
            }
            QLabel {
                font-size: 18px;
                color: #333;
                font-weight: bold;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border-radius: 6px;
                padding: 8px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)

        layout = QVBoxLayout()
        welcome_label = QLabel("🎉 Selamat Datang di Aplikasi Deteksi Objek 🎉")
        welcome_label.setAlignment(Qt.AlignCenter)

        start_button = QPushButton("Mulai Aplikasi")
        start_button.clicked.connect(self.open_main_window)

        layout.addStretch()
        layout.addWidget(welcome_label)
        layout.addSpacing(20)
        layout.addWidget(start_button)
        layout.addStretch()

        self.setLayout(layout)

    def open_main_window(self):
        self.main_window = ObjectDetector()
        self.main_window.show()
        self.close()


class ObjectDetector(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Deteksi Objek Ringkas")
        self.setFixedSize(500, 600)

        self.setStyleSheet("""
            QWidget {
                background-color: #f0f0f5;
                font-family: Arial;
            }
            QLabel {
                font-size: 12px;
                color: #333;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border-radius: 4px;
                padding: 6px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QGroupBox {
                font-weight: bold;
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 8px;
                font-size: 12px;
            }
            QSlider::handle:horizontal {
                background: #4CAF50;
                border: 1px solid #999;
                width: 12px;
                margin: -5px 0;
                border-radius: 6px;
            }
        """)

        self.cap = None
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)

        self.canny_low = 100
        self.canny_high = 200
        self.min_area = 1000

        self.image_label = QLabel()
        self.image_label.setFixedSize(400, 300)
        self.image_label.setStyleSheet("background-color: #ccc; border: 2px solid #999;")
        self.info_label = QLabel("Jumlah Objek: 0")

        self.camera_button = QPushButton("📷 Buka Kamera")
        self.stop_button = QPushButton("⛔ Stop Kamera")
        self.image_button = QPushButton("🖼 Buka Gambar")
        self.save_button = QPushButton("📄 Simpan Hasil")
        self.save_button.clicked.connect(self.save_result)

        self.slider_canny_low = QSlider(Qt.Horizontal)
        self.slider_canny_low.setRange(0, 500)
        self.slider_canny_low.setValue(self.canny_low)
        self.slider_canny_low.valueChanged.connect(self.update_canny_low)

        self.slider_canny_high = QSlider(Qt.Horizontal)
        self.slider_canny_high.setRange(0, 500)
        self.slider_canny_high.setValue(self.canny_high)
        self.slider_canny_high.valueChanged.connect(self.update_canny_high)

        self.slider_min_area = QSlider(Qt.Horizontal)
        self.slider_min_area.setRange(100, 10000)
        self.slider_min_area.setValue(self.min_area)
        self.slider_min_area.valueChanged.connect(self.update_min_area)

        main_layout = QVBoxLayout()
        image_layout = QVBoxLayout()
        image_layout.addWidget(self.image_label)
        image_layout.addWidget(self.info_label)

        control_layout = QVBoxLayout()
        control_layout.addWidget(self.camera_button)
        control_layout.addWidget(self.stop_button)
        control_layout.addWidget(self.image_button)
        control_layout.addWidget(self.save_button)

        slider_group = QGroupBox("🎚 Kontrol Parameter")
        slider_layout = QFormLayout()
        slider_layout.addRow("Canny Bawah", self.slider_canny_low)
        slider_layout.addRow("Canny Atas", self.slider_canny_high)
        slider_layout.addRow("Min Area", self.slider_min_area)
        slider_group.setLayout(slider_layout)

        main_layout.addLayout(image_layout)
        main_layout.addLayout(control_layout)
        main_layout.addWidget(slider_group)
        self.setLayout(main_layout)

        self.camera_button.clicked.connect(self.start_camera)
        self.stop_button.clicked.connect(self.stop_camera)
        self.image_button.clicked.connect(self.load_image)

    def update_canny_low(self, value):
        self.canny_low = value

    def update_canny_high(self, value):
        self.canny_high = value

    def update_min_area(self, value):
        self.min_area = value

    def start_camera(self):
        self.cap = cv2.VideoCapture(0)
        self.timer.start(30)

    def stop_camera(self):
        if self.cap:
            self.timer.stop()
            self.cap.release()
            self.cap = None

    def load_image(self):
        self.stop_camera()
        file_path, _ = QFileDialog.getOpenFileName(self, "Pilih Gambar", "", "Images (*.png *.jpg *.jpeg)")
        if file_path:
            img = cv2.imread(file_path)
            self.display_and_detect(img)

    def update_frame(self):
        if self.cap:
            ret, frame = self.cap.read()
            if ret:
                self.display_and_detect(frame)

    def display_and_detect(self, frame):
        resized = cv2.resize(frame, (400, 300))
        gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blur, self.canny_low, self.canny_high)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        dilated = cv2.dilate(edges, kernel, iterations=1)
        contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        filtered = [cnt for cnt in contours if cv2.contourArea(cnt) > self.min_area]

        for i, cnt in enumerate(filtered):
            x, y, w, h = cv2.boundingRect(cnt)
            cv2.rectangle(resized, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(resized, f"Obj {i+1}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        self.info_label.setText(f"Jumlah Objek: {len(filtered)}")

        rgb_image = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.image_label.setPixmap(QPixmap.fromImage(qt_image))

    def save_result(self):
        count_text = self.info_label.text()
        file_path, _ = QFileDialog.getSaveFileName(self, "Simpan Hasil", "", "Text Files (*.txt)")
        if file_path:
            with open(file_path, 'w') as file:
                file.write(count_text)
            print(f"Hasil disimpan ke: {file_path}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    welcome = WelcomeScreen()
    welcome.show()
    sys.exit(app.exec_())
